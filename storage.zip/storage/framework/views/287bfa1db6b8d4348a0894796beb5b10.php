<?php $__env->startSection('header'); ?>
    <header class="top-header d-flex justify-content-between align-items-center text-white">
        <a href="<?php echo e(Route('wali_kelas.presensi')); ?>" class="back-arrow"><i class="bi bi-arrow-left"></i></a>
        <h5 class="mb-0 flex-grow-1 text-center">Rekap Presensi</h5>
    </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-3">
        <form method="GET" class="mb-3 row g-2 align-items-end">
            <div class="row">
                <div class="col-6">
                    <label for="tanggal_awal" class="form-label">Dari Tanggal</label>
                    <input type="date" name="tanggal_awal" id="tanggal_awal" class="form-control"
                        value="<?php echo e(request('tanggal_awal')); ?>">
                </div>
                <div class="col-6">
                    <label for="tanggal_akhir" class="form-label">Sampai Tanggal</label>
                    <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control"
                        value="<?php echo e(request('tanggal_akhir')); ?>">
                </div>
            </div>
            <div class="text-center mt-3">
                <button class="btn btn-success w-100">Tampilkan</button>
            </div>
        </form>

        <div class="table-responsive">
            <table id="table1" class="table table-bordered table-striped nowrap" style="width:100%">
                <thead class="table-light">
                    <tr>
                        <th>Tanggal</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Mapel</th>
                        <th>Status</th>
                        <th>Materi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($data->tanggal); ?></td>
                            <td><?php echo e($data->siswa->nama_lengkap); ?></td>
                            <td><?php echo e($data->jadwal->kelas->nama_kelas); ?></td>
                            <td><?php echo e($data->jadwal->mataPelajaran->nama_mapel ?? '-'); ?></td>
                            <td><?php echo e($data->status_presensi); ?></td>
                            <td><?php echo e($data->materi); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">Data tidak ditemukan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\walikelas\presensi-rekap.blade.php ENDPATH**/ ?>