<?php $__env->startSection('header'); ?>
    <header class="top-header d-flex justify-content-center align-items-center">
        <h5 class="mb-0 text-white text-center">Nilai</h5>
    </header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <nav class="subject-tabs mb-3">
        <ul class="nav nav-pills">
            <?php $__currentLoopData = $nilaiRingkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel => $nilaiGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" style="display: inline-block;">
                    <a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>"
                    data-bs-toggle="tab"
                    href="#tab-<?php echo e(Str::slug($mapel)); ?>">
                        <?php echo e($mapel); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </nav>

    <main class="grades-list">
        <div class="tab-content grades-list">
            <?php $__currentLoopData = $nilaiRingkas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel => $kelasGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="tab-<?php echo e(Str::slug($mapel)); ?>">
                    <div class="subject-section mb-4">
                        <?php $__currentLoopData = $kelasGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas => $jenisGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="kelas-section mb-3">
                                <h6 class="text-secondary"><?php echo e($kelas); ?></h6>

                                <ul class="list-group">
                                    <?php $__currentLoopData = $jenisGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis => $dataNilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?php echo e($jenis); ?></strong> - <?php echo e($dataNilai->count()); ?> siswa
                                                <br>
                                                <small class="text-muted">
                                                    Tanggal <?php echo e(\Carbon\Carbon::parse($dataNilai->first()->tanggal_input)->translatedFormat('d M Y')); ?>

                                                </small>
                                            </div>
                                            <a href="<?php echo e(route('wali_kelas.detail', ['mapel' => $dataNilai->first()->mapel_id, 'kelas' => $dataNilai->first()->siswa->kelas_id, 'jenis' => $jenis])); ?>"
                                            class="btn btn-outline-success">
                                                Lihat Detail
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>

    <a href="<?php echo e(Route('wali_kelas.tambah')); ?>" class="fab">
        <i class="bi bi-plus-lg text-white"></i>
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
    <nav class="nav bottom-nav fixed-bottom d-flex justify-content-between bg-light">
        <a class="nav-link text-center flex-fill" href="<?php echo e(Route('wali_kelas.presensi')); ?>">
            <i class="bi bi-journal-check"></i>
            Presensi
        </a>
        <a class="nav-link text-center flex-fill text-success" href="#">
            <i class="bi bi-award-fill"></i>
            Nilai
        </a>
        <a class="nav-link text-center flex-fill" href="<?php echo e(Route('wali_kelas.dashboard')); ?>">
            <i class="bi bi-house-door"></i>
            Beranda
        </a>
        <a class="nav-link text-center flex-fill" href="<?php echo e(Route('wali_kelas.siswa')); ?>">
            <i class="bi bi-people"></i>
            Siswa
        </a>
        <a class="nav-link text-center flex-fill" href="<?php echo e(Route('catatan.wali')); ?>">
            <i class="bi bi-list-stars"></i>
            Catatan
        </a>
    </nav>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\walikelas\nilai.blade.php ENDPATH**/ ?>