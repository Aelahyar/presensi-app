<?php $__env->startSection('header'); ?>
    <header class="top-header d-flex justify-content-between align-items-center text-white">
        <a href="<?php echo e(Route('catatan.wali')); ?>" class="back-arrow"><i class="bi bi-arrow-left"></i></a>
        <h5 class="mb-0 flex-grow-1 text-center">Detail Catatan</h5>
    </header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="card mb-3">
        <div class="card-header bg-primary text-white">
            Informasi Siswa
        </div>
        <div class="card-body">
            <p><strong>Nama Siswa:</strong> <?php echo e($catatan->siswa->nama_lengkap); ?></p>
            <p><strong>NISN:</strong> <?php echo e($catatan->siswa->nisn); ?></p>
            <p><strong>Jenis Kelamin:</strong> <?php echo e($catatan->siswa->jenis_kelamin); ?></p>
            <p><strong>Alamat:</strong> <?php echo e($catatan->siswa->alamat); ?></p>
        </div>
    </div>

    <div class="card mb-3">
        <div class="card-header bg-warning text-dark">
            Detail Pelanggaran
        </div>
        <div class="card-body">
            <p><strong>Pelapor:</strong> <?php echo e($catatan->user->username); ?> (<?php echo e($catatan->user->email); ?>)</p>
            <p><strong>Tanggal Kejadian:</strong> <?php echo e(\Carbon\Carbon::parse($catatan->tanggal_kejadian)->format('d M Y')); ?></p>
            <p><strong>Jenis Pelanggaran:</strong> <?php echo e($catatan->jenis_pelanggaran); ?></p>
            <p><strong>Deskripsi:</strong> <?php echo e($catatan->deskripsi_pelanggaran); ?></p>
            <p><strong>Status Penanganan:</strong> <span class="badge bg-info"><?php echo e($catatan->status_penanganan); ?></span></p>
            <p><strong>Tanggal Dilaporkan:</strong> <?php echo e(\Carbon\Carbon::parse($catatan->tanggal_dilaporkan)->format('d M Y H:i')); ?></p>
            <?php if($catatan->tanggal_selesai_penanganan): ?>
                <p><strong>Tanggal Selesai Penanganan:</strong> <?php echo e(\Carbon\Carbon::parse($catatan->tanggal_selesai_penanganan)->format('d M Y H:i')); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <?php if($catatan->tindakan_wali_kelas): ?>
    <div class="card mb-3">
        <div class="card-header bg-success text-white">
            Tindakan Wali Kelas
        </div>
        <div class="card-body">
            <p><?php echo e($catatan->tindakan_wali_kelas); ?></p>
        </div>
    </div>
    <?php endif; ?>

    <?php if($catatan->tindakan_bk): ?>
    <div class="card mb-3">
        <div class="card-header bg-danger text-white">
            Tindakan BK
        </div>
        <div class="card-body">
            <p><?php echo e($catatan->tindakan_bk); ?></p>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\walikelas\catatan-show.blade.php ENDPATH**/ ?>