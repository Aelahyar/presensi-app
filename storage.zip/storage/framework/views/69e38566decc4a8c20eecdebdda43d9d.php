<?php $__env->startSection('header'); ?>
    <div class="options-container">
        <div class="options-header">
            <a href="<?php echo e(Route('wali_kelas.option')); ?>" class="text-decoration-none back-icon">
                <i class="bi bi-chevron-left"></i>
            </a>
            <h4>Profile</h4>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <div class="text-center mb-2">
        <img src="<?php echo e(asset('assets/img/pap.jpg')); ?>" class="mb-1" width="120" alt="">
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success" id="success-alert">
            <?php echo e(session('success')); ?>

        </div>

        <script>
            setTimeout(function () {
                const alert = document.getElementById('success-alert');
                if (alert) {
                    alert.style.transition = 'opacity 0.5s ease';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500); // Hapus dari DOM setelah animasi selesai
                }
            }, 3000); // 3 detik
        </script>
    <?php endif; ?>

    <form action="<?php echo e(route('wali_kelas.profil.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" value="<?php echo e(old('username', $user->username)); ?>" class="form-control">
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn w-100 py-2 btn-success mb-3">Simpan</button>
    </form>


</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        setTimeout(function () {
            $('#success-alert').fadeOut('slow', function () {
                $(this).remove();
            });
        }, 3000);
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\walikelas\profil.blade.php ENDPATH**/ ?>