<?php $__env->startSection('header'); ?>
    <div class="options-container">
        <div class="options-header">
            <a href="<?php echo e(Route('wali_kelas.option')); ?>" class="text-decoration-none back-icon">
                <i class="bi bi-chevron-left"></i>
            </a>
            <h4>Update Password</h4>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
    <?php if(session('success')): ?>
        <div class="alert alert-success" id="success-alert">
            <?php echo e(session('success')); ?>

        </div>
        <script>
            setTimeout(() => {
                const alert = document.getElementById('success-alert');
                alert.style.transition = 'opacity 0.5s ease';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            }, 3000);
        </script>
    <?php endif; ?>

    <form action="<?php echo e(route('wali_kelas.password.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="password_lama" class="form-label">Password Lama</label>
            <input type="text" name="password_lama" class="form-control">
            <?php $__errorArgs = ['password_lama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="password_baru" class="form-label">Password Baru</label>
            <div class="input-group">
                <input type="password" name="password_baru" class="form-control" id="passwordBaru">
                <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('passwordBaru')">
                    
                    <i class="bi bi-eye-slash" id="icon-passwordBaru"></i>
                </button>
            </div>
            <?php $__errorArgs = ['password_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label for="password_baru_confirmation" class="form-label">Konfirmasi Password Baru</label>
            <div class="input-group">
                <input type="password" name="password_baru_confirmation" class="form-control" id="passwordBaruKonfirmasi">
                <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('passwordBaruKonfirmasi')">
                    
                    <i class="bi bi-eye-slash" id="icon-passwordBaruKonfirmasi"></i>
                </button>
            </div>
        </div>

        <button type="submit" class="btn w-100 py-2 btn-success mb-3">Simpan Password Baru</button>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
    function togglePassword(id) {
        const input = document.getElementById(id);
        const icon = document.getElementById('icon-' + id);

        if (input.type === "password") {
            input.type = "text";
            icon.classList.remove('bi-eye');
            icon.classList.add('bi-eye-slash');
        } else {
            input.type = "password";
            icon.classList.remove('bi-eye-slash');
            icon.classList.add('bi-eye');
        }
    }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\walikelas\ganti-password.blade.php ENDPATH**/ ?>