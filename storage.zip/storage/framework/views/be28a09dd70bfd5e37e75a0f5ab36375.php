<?php $__env->startSection('content'); ?>
    <header class="top-header d-flex justify-content-between align-items-center text-white">
        <a href="<?php echo e(Route('wali_kelas.nilai')); ?>" class="back-arrow"><i class="bi bi-arrow-left"></i></a>
        <h5 class="mb-0">Detail Penilaian</h5>
        <form action="<?php echo e(route('nilai.destroyGroup')); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus semua nilai ini?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <input type="hidden" name="mapel_id" value="<?php echo e($dataNilai->first()->mapel_id); ?>">
            <input type="hidden" name="kelas_id" value="<?php echo e($dataNilai->first()->siswa->kelas_id); ?>">
            <input type="hidden" name="jenis_nilai" value="<?php echo e($dataNilai->first()->jenis_nilai); ?>">

            <button type="submit" class="btn btn-sm text-danger delete-icon" style="background: none; border: none;">
                <i class="bi bi-trash"></i>
            </button>
        </form>
    </header>
    <section class="assessment-details">
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <h6 class="title mb-1"><?php echo e($jenis_nilai); ?></h6>
                <p class="date-info mb-0"><?php echo e(\Carbon\Carbon::parse($tanggal_input)->translatedFormat('d M Y')); ?></p>
            </div>
            <a href="<?php echo e(route('nilai.editGroup', [
                    'mapel' => $dataNilai->first()->mapel_id,
                    'kelas' => $dataNilai->first()->siswa->kelas_id,
                    'jenis' => $dataNilai->first()->jenis_nilai
                ])); ?>" class="edit-icon">
                    <i class="bi bi-pencil-fill"></i>
                </a>
        </div>
        <div class="row">
            <div class="col-6">
                <p class="info-label">Mapel</p>
                <p class="info-value"><?php echo e($mapel); ?></p>
            </div>
            <div class="col-6">
                <p class="info-label">Kelas</p>
                <p class="info-value"><?php echo e($kelas); ?></p>
            </div>
        </div>
    </section>

    <div class="table-responsive table-container">
        <table id="table1" class="table table-bordered table-striped nowrap" style="width:100%">
            <thead>
                <tr>
                    <th class="text-center" style="width: 10%;">No</th>
                    <th style="width: 55%;">Siswa (<?php echo e($dataNilai->count()); ?>)</th>
                    <th style="width: 15%;">Nilai</th>
                    <th style="width: 15%;">Predikat</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dataNilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><small class="text-muted d-block"><?php echo e($index + 1); ?></small></td>
                        <td class="text-start"><?php echo e($nilai->siswa->nama_lengkap); ?></td>
                        <td class="grade-zero"><?php echo e($nilai->nilai); ?></td>
                        <td class="text-center"><?php echo e($nilai->keterangan); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\walikelas\detail.blade.php ENDPATH**/ ?>