<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Admin Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Welcome, <?php echo e(optional(Auth::user()->profile)->nama_lengkap ?? Auth::user()->username); ?>!
                    You are logged in as Admin.
                </div>
            </div>
        </div>
    </div>
    <form action="<?php echo e(route('logout')); ?>" method="POST" onsubmit="return confirm('Yakin ingin keluar?')">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-danger">
        Keluar
    </button>
</form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>