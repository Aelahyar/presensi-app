<?php $__env->startSection('header'); ?>
    <div class="options-container">
        <div class="options-header">
            <a href="<?php echo e(Route('wali_kelas.dashboard')); ?>" class="text-decoration-none back-icon">
                <i class="bi bi-chevron-left"></i>
            </a>
            <h4>Options</h4>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="list-container">
            <div class="section-title">Accounts</div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">
                    <div class="item-content">
                        <i class="bi bi-person item-icon"></i>
                        <span>Edit Profile</span>
                    </div>
                    <a href="<?php echo e(Route('wali_kelas.profil')); ?>" class="text-decoration-none d-flex justify-content-between align-items-center">
                        <i class="bi bi-chevron-right chevron-icon"></i>
                    </a>
                </li>
                <li class="list-group-item">
                    <div class="item-content">
                        <i class="bi bi-key item-icon"></i>
                        <span>Change Password</span>
                    </div>
                    <a href="<?php echo e(Route('wali_kelas.password.form')); ?>" class="text-decoration-none d-flex justify-content-between align-items-center">
                    <i class="bi bi-chevron-right chevron-icon"></i>
                    </a>
                </li>
            </ul>

            

            <div class="logout-link">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Log out current account</button>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\walikelas\option.blade.php ENDPATH**/ ?>