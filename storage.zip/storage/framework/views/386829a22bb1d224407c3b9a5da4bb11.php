<?php $__env->startSection('header'); ?>
<header class="header">
    <div class="d-flex align-items-center justify-content-between">
        <div class="d-flex align-items-center">
            <img src="<?php echo e(asset('assets/img/pap.jpg')); ?>" alt="Foto Profil" class="profile-pic me-3">
            <div>
                <p>Selamat Datang,</p>
                <h5><?php echo e(optional(Auth::user()->guru)->nama_lengkap ?? Auth::user()->username); ?></h5>
            </div>
        </div>
        <a href="#" class="settings-icon">
            <i class="bi bi-gear"></i>
        </a>
    </div>
</header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="container py-3">

    <div class="mb-4">
        <h6 class="fw-bold mb-3">Pelajaran Berlangsung</h6>
        <?php if($jadwalBerlangsung->isEmpty()): ?>
            <div class="text-muted small mb-2">Tidak ada jadwal untuk saat ini.</div>
        <?php else: ?>
            <?php $__currentLoopData = $jadwalBerlangsung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelasNama => $jadwals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card custom-card mb-2">
                        <div class="card-body d-flex align-items-center">
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-1"><?php echo e($jadwal->mataPelajaran->nama_mapel); ?></h6>
                                <p class="text-muted small mb-2"><?php echo e($kelasNama); ?></p>
                                <div>
                                    <span class="me-3 small text-muted">
                                        <i class="bi bi-clock me-1"></i><?php echo e($jadwal->jam_mulai); ?> - <?php echo e($jadwal->jam_selesai); ?>

                                    </span>
                                    <span class="small text-muted">
                                        <i class="bi bi-people me-1"></i><?php echo e($jadwal->kelas->siswa->count() ?? 0); ?> Siswa
                                    </span>
                                </div>
                            </div>
                            
                                <i class="bi bi-chevron-right text-muted"></i>
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <div>
        <h6 class="fw-bold mb-3">Jadwal Hari Ini</h6>
        <div class="card custom-card">
            <div class="list-group list-group-flush">
                <?php if($mengajars->isEmpty()): ?>
                    <p class="mb-0 text-muted small">Tidak ada jadwal yang tersedia.</p>
                <?php else: ?>
                    <?php $__currentLoopData = $mengajars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelasNama => $jadwals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $jadwals->sortBy('jam_mulai'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center schedule-item">
                                <div>
                                    <div class="fw-bold"><?php echo e($jadwal->mataPelajaran->nama_mapel); ?></div>
                                    <div class="schedule-time"><?php echo e($jadwal->jam_mulai); ?> - <?php echo e($jadwal->jam_selesai); ?></div>
                                </div>
                                <div class="schedule-class"><?php echo e($kelasNama); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav'); ?>
<nav class="nav bottom-nav fixed-bottom d-flex justify-content-between bg-light">
    <a class="nav-link text-center flex-fill text-success" href="#">
        <i class="bi bi-house-door-fill"></i>
        Beranda
    </a>
    <a class="nav-link text-center flex-fill" href="#">
        <i class="bi bi-journal-check"></i>
        Presensi
    </a>
    <a class="nav-link text-center flex-fill" href="#">
        <i class="bi bi-award"></i>
        Nilai
    </a>
</nav>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\request\presensi-app\resources\views\guru\dashboard.blade.php ENDPATH**/ ?>