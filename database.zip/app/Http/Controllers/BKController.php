<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BKController extends Controller
{
    //
}
